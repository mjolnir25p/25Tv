# TV25 Android v4

Correção baseada no relatório de erro real do B2 Pro:
`ClassNotFoundException: pt.tv25.app.MainActivity`.

A v3 tinha a Activity em Kotlin, mas o projeto Gradle só aplicava o plugin Android/Java,
por isso o ficheiro Kotlin não era compilado para o APK. A v4 usa MainActivity.java,
eliminando essa incompatibilidade sem adicionar dependências Kotlin.

Mantém o ícone TV25, WebView, JavaScript/DOM storage, ficheiros e fullscreen.
